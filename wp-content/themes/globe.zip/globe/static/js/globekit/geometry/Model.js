"use strict";

var GK = GK || {};
GK.Model = function(vertices, indices) {
    this.vertices = vertices;
    this.indices = indices;
}
