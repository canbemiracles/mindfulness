<?php get_header(); ?>
<div id="main-calendar">
<div id="calendar-events"><?php echo do_shortcode('[events_calendar long_events=0 ]');?></div>
<div id="calendar-front">
<?php 
	if(have_posts()):the_post(); ?>
		<?php the_title(); ?>
		<?php the_content(); ?>	
	<?php endif; ?>
</div>
</div>
<?php get_footer(); ?>